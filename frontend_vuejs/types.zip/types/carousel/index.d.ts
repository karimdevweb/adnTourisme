declare module 'vue-slick-carousel';
declare module 'leaflet';
declare module 'lottie-vuejs/src/LottieAnimation.vue';